extern "C" {
hash_map_char<char*> *load_snp_set(FILE *fp);
}
