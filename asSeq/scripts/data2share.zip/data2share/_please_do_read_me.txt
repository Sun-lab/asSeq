YRI_counts_per_gene_pitchard.txt
	total read count per gene, downloaded from pritchard website

YRI_asCounts_per_gene_data.txt
	allele-specific count

gene_expression_levels_qqnorm_pccor_info.txt
	the information of each gene, matched row by row with file YRI_asCounts_per_gene_data.txt and YRI_counts_per_gene_pitchard.txt

YRI_samples.txt
	sample information. 

PCA_eigenvectors.txt
	PC calculated using TReC data after trnansformation: log10[(TReC per gene + 1/6)/(TReC per sample)]

trecaseP_eQTL_by_gene.txt
	the column of nuse_* are the number of permutations I used. I will stop permutation if it obvious that I will get an insignificant permutation p-value. other column names should be self-explanatory
	
Let me know if you have questions. 
weisun@email.unc.edu
http://www.bios.unc.edu/~weisun
