
chr1 = 22

library(asSeq) 

setwd("~/research/eQTL_seq/data/YRI/")

# -------------------------------------------------------------------------
# read the data and info
# -------------------------------------------------------------------------

datT  = read.table(file = "YRI_counts_per_gene_pitchard.txt", sep = "\t", 
header = TRUE, as.is=TRUE)

info = read.table(file = "results/gene_expression_levels_qqnorm_pccor_info.txt", 
sep = "\t", header = TRUE, as.is=TRUE)

dim(datT)
dim(info)

datT[1:2, 1:8]
info[1:2,]

sams = names(datT)

# -------------------------------------------------------------------------
# The total number of reads per sample
# -------------------------------------------------------------------------

cntAll = colSums(datT)

# -------------------------------------------------------------------------
# read the information of PCs
# -------------------------------------------------------------------------

pcs = read.table("PCA_eigenvectors.txt", sep = "\t", header = TRUE)
dim(pcs)
pcs[1:2,1:5]

pcs = data.matrix(pcs)
X = cbind(log(cntAll), pcs[,1:6])

cn = read.table("YRI_samples.txt", sep="\t", header=TRUE)
dim(cn)

if(any(cn$name != sams)){
  stop("sample ID do not match\n")
}

X = cbind(X, as.numeric(cn$gender))

# -------------------------------------------------------------------------
# read AS expression data and info
# -------------------------------------------------------------------------

datA = read.table(file = "YRI_asCounts_per_gene_data.txt", sep = "\t", header = TRUE)
dim(datA)

datA[1:2, 1:8]

# ---------------------------------------------------------------------
# test for cis-eQTL
# ---------------------------------------------------------------------

setwd("~/research/eQTL_seq/result/YRI_Joint/")

chr2 = sprintf("chr%d", chr1)

st1 = "\n---------------------------------------------------\n"
message(sprintf("%s chr: %d %s", st1, chr1, st1))

# -------------------------------------------------------------------------
# Prepare gene expression data
# -------------------------------------------------------------------------

wchr = which(info$chrom == chr2)

if(length(wchr) == 0){
  warninng("no genes at", chr2)
  next
}

eDatT = datT[wchr,]
eDatA = datA[wchr,]
einfo = info[wchr,]

dim(eDatT)
eDatT[1:2,1:5]

dim(einfo)
einfo[1:2,]

# -------------------------------------------------------------------------
# Prepare genotype data
# -------------------------------------------------------------------------

datFile = sprintf("../../data/YRI_hap_geno/YRI_hap_nume_%s_data.txt", chr2)
genoDat = read.table(datFile, comment.char = "", sep="\t", 
                     header = TRUE, as.is=TRUE)
dim(genoDat)
genoDat[1:2,1:5]

infFile = sprintf("../../data/YRI_hap_geno/YRI_hap_geno_%s_info.txt", chr2)
genoInf = read.table(infFile, comment.char = "", sep="\t", 
                     header = TRUE, as.is=TRUE)

dim(genoInf)
genoInf[1:2,]

tmpDat = data.matrix(genoDat)
ww2    = tmpDat > 2
tmpDat[ww2] = genoDat[ww2] - 2

maf = 0.5*apply(tmpDat, 1, sum)/ncol(tmpDat)
summary(maf)

# -------------------------------------------------------------------------
# keep those MAF >= 0.05
# -------------------------------------------------------------------------

wkp = which( maf >= 0.05)

genoDat = genoDat[wkp,]
genoInf = genoInf[wkp,]

message(sprintf("%d out of %d SNPs with MAF >= 0.05 are used", 
                length(wkp), length(maf)))

# -------------------------------------------------------------------------
# split expression data into two parts
# -------------------------------------------------------------------------

sams  = names(genoDat)
samsA = paste(sams,"A",sep="")
samsB = paste(sams,"B",sep="")

Y1 = eDatA[,match(samsA, names(eDatA))]
Y2 = eDatA[,match(samsB, names(eDatA))]

if(any(names(Y1) != samsA)){
  stop("names do not match\n")
}

if(any(names(Y2) != samsB)){
  stop("names do not match\n")
}

Y  = eDatT[,match(sams, names(eDatT))]

# -------------------------------------------------------------------------
# The actual computation
# -------------------------------------------------------------------------

Y1 = t(data.matrix(Y1))
Y2 = t(data.matrix(Y2))
dim(Y1)
dim(Y2)

Y  = t(data.matrix(Y))
dim(Y)

Z = t(data.matrix(genoDat))
dim(Z)

chrI = as.integer(chr1)
eChr = rep(chrI, ncol(Y1))
ePos = einfo$txStart

mChr = rep(chrI, ncol(Z))
mPos = genoInf$position_b36

message(date())

ta = trecase(Y, Y1, Y2, X, Z, output.tag=sprintf("trecase_%s", chr2), 
        p.cut=0.01, min.nTotal=5, min.N=5, min.Nhet=5, 
        cis.only = TRUE, cis.distance = 2e+05, 
        eChr = eChr, ePos = ePos, mChr = mChr, mPos = mPos, 
        trace = 0, maxit=100)

message(date())
